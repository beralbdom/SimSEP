% clear
%
% Renomear o arquivo com a configura��o completa de medidores do sistema
% para "FULL_SCADA.med"
%
[num, de, para, circ, tipo, PMU, ok, acc, fs, dp, ref, leitura]=textread('full_SCADA.med', '%s %s %s %s %s %s %s %s %s %s %s %s');
[nnum, nde, npara, ncirc, ntipo, nPMU, nok, nacc, nfs, ndp, nref, nleitura]=textread('full_SCADA.med');
tamanho=length(num);
%
% Medidas de Fluxo Ativo e Reativo
% Medidas de Inje��o Ativa e REativa
% Medidas de Modulo de Tens�o ( Medi��o Convencional )
% Medidas de Angulo de Tens�o ( AINDA EM PENSAMENTO )
%
% Se formos usar Medidas de Fluxo ativo e Inje��o Reativa responderemos a
% pergunta seguinte com "2"
% 
resposta=input('Quantos tipos de medidores deseja ? [1,2,3,4,5,6]  = ');
contador=1;contam=1;fluxo=0;injecao=0;tensao=0;angulo=0;
while contador <= resposta
    %
    % Usa conven��o de Rui e seguindo exemplo anterior deve-se escolher "1"
    % na primeira vez da pergunta e "5" na segunda vez
    %
    tipomed=input('Qual Tipo de Medidor Deseja ? [1 a 10]  = ');
    for i=1:tamanho
        if ntipo(i)==tipomed
            indice(contam)=i;
            contam=contam+1;
        end
        if (ntipo(i)==1) || (ntipo(i)==4)
            fluxo=fluxo+1;
        elseif (ntipo(i)==2) || (ntipo(i)==5)
            injecao=injecao+1;
        elseif ntipo(i)==6
            tensao=tensao+1;
        elseif ntipo(i)==3
            angulo=angulo+1;            
        end
    end
    contador=contador+1;
end
%
% Ecolhe Barras de Inje��o
%
contam=contam-1;tamcon=1;
ninjecao=input('Digite a Qtde de Medidas de Inje��o ( considere medidas aos pares ):');
for i=1:ninjecao
    barra(i)=input('Barra = ');
end
for j=1:ninjecao
    for k=1:contam
        if (npara(indice(k))==barra(j))
             if (ntipo(indice(k))==2) || (ntipo(indice(k))==5)
                 indicef(tamcon)=indice(k);
                 tamcon=tamcon+1;
             end
        end
    end
end
%
% Ecolhe Barras de Fluxo
%
nfluxo=input('Digite a Qtde de Medidas de Fluxo ( considere medidas aos pares ):');
for i=1:nfluxo
    debarra(i)=input('De Barra = ');
    parabarra(i)=input('Para Barra = ');
end
for j=1:nfluxo
    for k=1:contam
        if (nde(indice(k))==debarra(j)) && (npara(indice(k))==parabarra(j))
            if (ntipo(indice(k))==1) || (ntipo(indice(k))==4)
                indicef(tamcon)=indice(k);
                tamcon=tamcon+1;
            end
        end
    end
end
%
% Ecolhe Barras de Tens�o
%
ntensao=input('Digite a Qtde de Medidas de Tens�o ( considere medidas de M�dulo ):');
for i=1:ntensao
    barrav(i)=input('Barra = ');
end
for j=1:ntensao
    for k=1:contam
        if (npara(indice(k))==barrav(j))
            if (ntipo(indice(k))==6)
                indicef(tamcon)=indice(k);
                tamcon=tamcon+1;
            end
        end
    end
end
%
% Ecolhe Barras de Tens�o para ANGULO e DEVE-SE PENSAR COMO CONVERTER
% MEDIDAS DE MODULO EM PMU QUANDO FOR IMPLEMENTAR
%
nangulo=input('Digite a Qtde de Medidas de Tens�o ( considere medidas de Angulo ):');
fprintf('Isto automaticamente transforma medidas de Modulo de Tens�o em PMU�s nas barras onde forem instaladas\n')
for i=1:nangulo
    barrat(i)=input('Barra = ');
end
%
% IMPLEMENTA��O DA INSTALA��O DE PMU SOMENTE COM TENS�O
%
tamcon=tamcon-1;
for k=1:tamcon
    M(k,1)=num(k);
    M(k,2)=de(indicef(k));
    M(k,3)=para(indicef(k));
    M(k,4)=circ(indicef(k));
    M(k,5)=tipo(indicef(k));
    M(k,6)=PMU(indicef(k));
    M(k,7)=ok(indicef(k));
    M(k,8)=acc(indicef(k));
    M(k,9)=fs(indicef(k));
    M(k,10)=dp(indicef(k));
    M(k,11)=ref(indicef(k));
    M(k,12)=leitura(indicef(k));
end
% dlmwrite('casetest.med', [M])
% casewrite
% tblwrite
% fwrite
% save
% fid fopen fclose
format = '%04i %04i %04i %02i %02i %03i %01i %05.3f %05.3f %10.6f %+10.5f %+10.5f\n';
fid=fopen('casetest.med', 'wt')
fprintf(fid, format, M)
fclose(fid)