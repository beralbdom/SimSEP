%
% Renomear o arquivo com a configura��o completa de medidores do sistema
% para "FULL_SCADA.med"
%
[num, de, para, circ, tipo, PMU, ok, acc, fs, dp, ref, leitura]=textread('full_SCADA.med', '%s %s %s %s %s %s %s %s %s %s %s %s');
[nnum, nde, npara, ncirc, ntipo, nPMU, nok, nacc, nfs, ndp, nref, nleitura]=textread('full_SCADA.med');
tamanho=length(num);
%
% Medidas de Fluxo Ativo e Reativo
% Medidas de Inje��o Ativa e REativa
% Medidas de Modulo de Tens�o ( Medi��o Convencional )
% Medidas de Angulo de Tens�o ( AINDA EM PENSAMENTO )
%
% Se formos usar Medidas de Fluxo ativo e Inje��o Reativa responderemos a
% pergunta seguinte com "2"
% 
resposta=input('Quantos tipos de medidores deseja ? [1,2,3,4,5,6]  = ');
contador=1;contam=1;fluxo=0;injecao=0;tensao=0;angulo=0;
while contador <= k
    %
    % Usa conven��o de Rui e seguindo exemplo anterior deve-se escolher "1"
    % na primeira vez da pergunta e "5" na segunda vez
    %
    tipomed=input('Qual Tipo de Medidor Deseja ? [1 a 10]  = ');
    for i=1:tamanho
        if ntipo(i)==tipomed
            pnum(contam)=num(i);
            pde(contam)=de(i);
            ppara(contam)=para(i);
            pcirc(contam)=circ(i);
            ptipo(contam)=tipo(i);
            pPMU(contam)=PMU(i);
            pok(contam)=ok(i);
            pacc(contam)=acc(i);
            pfs(contam)=fs(i);
            pdp(contam)=dp(i);
            pref(contam)=ref(i);
            pleitura(contam)=leitura(i);
            contam=contam+1;
        end
        if (ntipo(i)==1) || (ntipo(i)==4)
            fluxo=fluxo+1;
        elseif (ntipo(i)==2) || (ntipo(i)==5)
            injecao=injecao+1;
        elseif ntipo(i)==6
            tensao=tensao+1;
        elseif ntipo(i)==3
            angulo=angulo+1;            
        end
        
    end
    contador=contador+1;
end
%
% Ecolhe Barras de Inje��o
%
contam=1;
ninjecao=input('Digite a Qtde de Medidas de Inje��o ( considere medidas aos pares ):');
for i=1:ninjecao
    barra(i)=input('Barra = ');
end

%
% Ecolhe Barras de Fluxo
%
nfluxo=input('Digite a Qtde de Medidas de Fluxo ( considere medidas aos pares ):');
for i=1:nfluxo
    debarra(i)=input('De Barra = ');
    parabarra(i)=input('Para Barra = ');
end
%
% Ecolhe Barras de Tens�o
%
ntensao=input('Digite a Qtde de Medidas de Tens�o ( considere medidas de M�dulo ):');
for i=1:ntensao
    barra(i)=input('Barra = ');
end
%
% Ecolhe Barras de Tens�o para ANGULO e DEVE-SE PENSAR COMO CONVERTER
% MEDIDAS DE MODULO EM PMU QUANDO FOR IMPLEMENTAR
%
nangulo=input('Digite a Qtde de Medidas de Tens�o ( considere medidas de Angulo ):');
fprintf('Isto automaticamente transforma medidas de Modulo de Tens�o em PMU�s nas barras onde forem instaladas')
for i=1:nangulo
    barra(i)=input('Barra = ');
end
%
% IMPLEMENTA��O DA INSTALA��O DE PMU SOMENTE COM TENS�O
%