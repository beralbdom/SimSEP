% Renomear o arquivo com a configura��o completa de medidores do sistema
% para "FULL_SCADA.med"
[num, de, para, circ, tipo, PMU, ok, acc, fs, dp, ref, leitura]=textread('full_SCADA.med', '%s %s %s %s %s %s %s %s %s %s %s %s');
[nnum, nde, npara, ncirc, ntipo, nPMU, nok, nacc, nfs, ndp, nref, nleitura]=textread('full_SCADA.med');
tamanho=length(num);
resposta=input('Quantos tipos de medidores deseja ? [1,2,3,4,5,6]  = ', 's');
if resposta=='1'
    k=1;
elseif resposta=='2'
    k=2;
elseif resposta=='3'
    k=3;
elseif resposta=='4'
    k=4;
elseif resposta=='5'
    k=5;
else
    k=6;
end
contador=1;contam=1;
while contador <= k
    tipomed=input('Qual Tipo de Medidor Deseja ? [1 a 10]  = ', 's');
    if tipomed=='1'
        for i=1:tamanho
            if ntipo(i)==1
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='2'
        for i=1:tamanho
            if ntipo(i)==2
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='3'
        for i=1:tamanho
            if ntipo(i)==3
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='4'
        for i=1:tamanho
            if ntipo(i)==4
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='5'
        for i=1:tamanho
            if ntipo(i)==5
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='6'
        for i=1:tamanho
            if ntipo(i)==6
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='7'
        for i=1:tamanho
            if ntipo(i)==7
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='8'
        for i=1:tamanho
            if ntipo(i)==8
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    elseif tipomed=='9'
        for i=1:tamanho
            if ntipo(i)==9
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    else
        for i=1:tamanho
            if ntipo(i)==10
                pnum(contam)=num(i);
                pde(contam)=de(i);
                ppara(contam)=para(i);
                pcirc(contam)=circ(i);
                ptipo(contam)=tipo(i);
                pPMU(contam)=PMU(i);
                pok(contam)=ok(i);
                pacc(contam)=acc(i);
                pfs(contam)=fs(i);
                pdp(contam)=dp(i);
                pref(contam)=ref(i);
                pleitura(contam)=leitura(i);
                contam=contam+1;
            end
        end
    end
    contador=contador+1;
end